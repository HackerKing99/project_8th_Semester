const paypal = require("paypal-rest-sdk");

paypal.configure({
  mode: "live",
  client_id: "AVDmL3bHNL5daoYWSbSIKAJ_2LWd-6udAEd-8538CaTNT7KRgRmLHzpA7oziqhf37a_RBhDDSTGcBJ4P",
  client_secret: "EFeAhBxsOkZ8RNKD9QjGQ_dMdp9g31jtcCiUdmdLxFMaxQk9rRADW-RuBXYJhb-GdOcUyqVzPP5clJAq",
});

module.exports = paypal;
