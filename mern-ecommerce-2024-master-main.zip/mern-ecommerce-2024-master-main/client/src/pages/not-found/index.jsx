function NotFound() {
  return <div>page doesn't exists</div>;
}

export default NotFound;
